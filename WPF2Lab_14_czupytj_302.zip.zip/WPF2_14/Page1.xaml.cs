﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF2_14
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        static int DirectoryCounter = 1;
        static int PasswordsCounter = 1;
        static int ImageCounter = 1;


        public Page1()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            LoginPage pg = new LoginPage();
            this.Content = pg;
        }

        private void Add_Directory_Click(object sender, RoutedEventArgs e)
        {
            DirectoryTree.Items.Add($"New Directory {DirectoryCounter}");
            DirectoryCounter++;
        }

        private void Add_Passwords_Click(object sender, RoutedEventArgs e)
        {
            DirectoryTree.Items.Add($"New Passwords {PasswordsCounter}");
            PasswordsCounter++;
        }

        private void Add_Image_Click(object sender, RoutedEventArgs e)
        {
            DirectoryTree.Items.Add($"New Image {ImageCounter}");
            ImageCounter++;
        }

        //private void Add_Subdirectory(object sender, RoutedEventArgs e)
        //{
        //    var x = (sender as TreeViewItem);
        //}
    }
}
